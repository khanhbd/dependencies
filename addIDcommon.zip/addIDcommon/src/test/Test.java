package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] test = new String[100000000][11];
		
		        int k = 0;
		        try {
		            CsvReader products = new CsvReader("/home/duykhanh/Desktop/ITSData/attachment_tb.csv");
		
		            products.readHeaders();
		            while (products.readRecord()) {
		                String timeStamp = products.get("time_stamp");
		                String carID = products.get("car_id");
		                String lon = products.get("lon");
//		                lon = lon.replace(",", ".");
		                Double lon1 = Double.parseDouble(lon);
		                double lon11 = (double)lon1/921600;
		                String lon12 = ""+lon11;
		                String lat = products.get("lat");
//		                lat = lat.replace(",", ".");
		                Double lat1 = Double.parseDouble(lat);
		                double lat11 = (double)lat1/921600;
		                String lat12 = ""+lat11;
		                String currentTime = products.get("current_time");
		                String state = products.get("state");
		                String direction = products.get("direction");
		                String speed = products.get("speed");
		                speed = speed.replace(",", ".");
		                String timePeriod = products.get("time_period");
		                if (Double.parseDouble(speed) > 0) {
		                    test[k][0] = timeStamp;
		                    test[k][1] = carID;
		                    test[k][2] = lon12;
		                    test[k][3] = lat12;
		                    test[k][4] = currentTime;
		                    test[k][5] = state;
		                    test[k][6] = direction;
		                    test[k][7] = speed;
		                    test[k][8] = timePeriod;
		                    k++;
		                }
		                
//		                if (k >= 300000) {
//		                    break;
//		                }
		            }
		
		            products.close();
		
		        } catch (FileNotFoundException e) {
		            e.printStackTrace();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		
		
		
		
		        String outputFile = "/home/duykhanh/Desktop/ITSData/reduce_attachment_tb1.csv";
		
		        // before we open the file check to see if it already exists
		        boolean alreadyExists = new File(outputFile).exists();
		
		        try {
		            // use FileWriter constructor that specifies open for appending
		            CsvWriter csvOutput = new CsvWriter(new FileWriter(outputFile, true), ',');
		
		            // if the file didn't already exist then we need to write out the header line
		            if (!alreadyExists) {
		                csvOutput.write("id");
		                csvOutput.write("time_stamp");
		                csvOutput.write("car_id");
		                csvOutput.write("lon");
		                csvOutput.write("lat");
		                csvOutput.write("current_time");
		                csvOutput.write("state");
		                csvOutput.write("direction");
		                csvOutput.write("speed");
		                csvOutput.write("time_period");
		                csvOutput.endRecord();
		            }
		            // else assume that the file already has the correct header line
		
		            // write out a few records
		            for (int i = 0; i < 300000000; i++) {
		                String id = ""+i;
		                csvOutput.write(id);
		                csvOutput.write(test[i][0]);
		                csvOutput.write(test[i][1]);
		                csvOutput.write(test[i][2]);
		                csvOutput.write(test[i][3]);
		                csvOutput.write(test[i][4]);
		                csvOutput.write(test[i][5]);
		                csvOutput.write(test[i][6]);
		                csvOutput.write(test[i][7]);
		                csvOutput.write(test[i][8]);
		                csvOutput.endRecord();
		            }
		
		            csvOutput.close();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
	}

}
