package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.csvreader.CsvWriter;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] test = new String[300000][11];
		int k = 0;

		// String lineList[] = null;
		FileInputStream fis = null;
		BufferedReader reader = null;

		try {
			fis = new FileInputStream(
					"/home/duykhanh/Desktop/ITSData/attachment_tb.csv");
			reader = new BufferedReader(new InputStreamReader(fis));
			String line = reader.readLine();
			while (line != null) {
				String[] lineList = line.split(",");
				if (lineList[0].equals("time_stamp")) {
					line = reader.readLine();
					continue;
				}
				double speedDouble;
				if (lineList.length == 10) {
					String speed = lineList[7] + "." + lineList[8];
					int n = speed.length();
					speed = speed.substring(1, n - 1);
					speedDouble = Double.parseDouble(speed);
					if (speedDouble > 0) {
						test[k][0] = lineList[0];
						test[k][1] = lineList[1];
						test[k][2] = lineList[2];
						test[k][3] = lineList[3];
						test[k][4] = lineList[4];
						test[k][5] = lineList[5];
						test[k][6] = lineList[6];
						test[k][7] = speed;
						test[k][8] = lineList[9];
						k++;
					}
				} else {
					String speed = lineList[7];
					int n = speed.length();
					speed = speed.substring(1, n - 1);
					speedDouble = Double.parseDouble(speed);
					if (speedDouble > 0) {
						test[k][0] = lineList[0];
						test[k][1] = lineList[1];
						test[k][2] = lineList[2];
						test[k][3] = lineList[3];
						test[k][4] = lineList[4];
						test[k][5] = lineList[5];
						test[k][6] = lineList[6];
						test[k][7] = speed;
						test[k][8] = lineList[8];
						k++;
					}
				}
				if (k >= 10000) {
					break;
				}
				line = reader.readLine();
			}
		} catch (FileNotFoundException ex) {
			Logger.getLogger(BufferedReader.class.getName()).log(Level.SEVERE,
					null, ex);
		} catch (IOException ex) {
			Logger.getLogger(BufferedReader.class.getName()).log(Level.SEVERE,
					null, ex);

		} finally {
			try {
				reader.close();
				fis.close();
			} catch (IOException ex) {
				Logger.getLogger(BufferedReader.class.getName()).log(
						Level.SEVERE, null, ex);
			}
		}

		String outputFile = "/home/duykhanh/Desktop/ITSData/reduce_attachment_tb1.csv";

		// before we open the file check to see if it already exists
		boolean alreadyExists = new File(outputFile).exists();

		try {
			// use FileWriter constructor that specifies open for appending
			CsvWriter csvOutput = new CsvWriter(
					new FileWriter(outputFile, true), ',');

			// if the file didn't already exist then we need to write out the
			// header line
			if (!alreadyExists) {
				csvOutput.write("id");
				csvOutput.write("time_stamp");
				csvOutput.write("car_id");
				csvOutput.write("lon");
				csvOutput.write("lat");
				csvOutput.write("current_time");
				csvOutput.write("state");
				csvOutput.write("direction");
				csvOutput.write("speed");
				csvOutput.write("time_period");
				csvOutput.endRecord();
			}
			// else assume that the file already has the correct header line

			// write out a few records
			for (int i = 0; i < 300000; i++) {
				Integer id = i;
				csvOutput.write(id.toString());
				csvOutput.write(test[i][0]);
				csvOutput.write(test[i][1]);
				csvOutput.write(test[i][2]);
				csvOutput.write(test[i][3]);
				csvOutput.write(test[i][4]);
				csvOutput.write(test[i][5]);
				csvOutput.write(test[i][6]);
				csvOutput.write(test[i][7]);
				csvOutput.write(test[i][8]);
				csvOutput.endRecord();
			}

			csvOutput.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
