package ITSData.test;

import geomesa.core.data.AccumuloFeatureStore;
import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.spark.SparkConf;
//import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.broadcast.Broadcast;
import org.geotools.data.DataStore;
import org.geotools.data.DataStoreFinder;
import org.geotools.data.FeatureSource;
import org.geotools.data.FeatureStore;
import org.geotools.data.Query;
import org.geotools.factory.CommonFactoryFinder;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.filter.text.cql2.CQLException;
import org.opengis.feature.Feature;
import org.opengis.feature.Property;
import org.opengis.feature.simple.SimpleFeatureType;
import org.opengis.filter.Filter;
import org.opengis.filter.FilterFactory2;

import ITSData.test.kdtree.KDTree;

import scala.Tuple2;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Copyright 2014 Commonwealth Computer Research, Inc.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the License); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

public class QueryTutorial {

	public static KDTree<GeoName> kdTree;

	private static final String FEATURE_NAME_ARG = "featureName";

	/**
	 * Creates a base filter that will return a small subset of our results.
	 * This can be tweaked to return different results if desired. Currently it
	 * should return 16 results.
	 * 
	 * @return
	 * 
	 * @throws CQLException
	 * @throws IOException
	 */
	public static void main(String[] args) throws Exception {
		// read command line options - this contains the connection to accumulo
		// and the table to query

		// get the feature store used to query the GeoMesa data
		StopWatch allTime = new StopWatch();
		StopWatch sparkTime = new StopWatch();

		// execute some queries
		// basicQuery(simpleFeatureTypeName, featureStore);
		allTime.start();
		// List<String> listLatLon =
		// basicProjectionQuery(simpleFeatureTypeName,featureStore);
		// System.out.println(listLatLon.size());

		sparkTime.start();

		ReverseGeocode reverseGeoCode = new ReverseGeocode(new FileInputStream(
				CONST.path_to_input_file + "/OSMData/WaysOfHCM.txt"), true);
		kdTree = reverseGeoCode.kdTree();

		// Spark
		SparkConf sparkConf = new SparkConf().setAppName("ITSSpark").setMaster("yarn-client");
		JavaSparkContext scc = new JavaSparkContext(sparkConf);
		// SparkContext sc = new SparkContext(sparkConf);

		JavaRDD<String> lines = scc.textFile("hdfs:///ITSData/reduce_attachment_tb.csv", 1);
		final Broadcast<KDTree<GeoName>> broadcastVal = scc.broadcast(kdTree);

		JavaPairRDD<String, Iterable<String>> listRoad = lines
				.mapToPair(new PairFunction<String, String, String>() {

					public Tuple2<String, String> call(String p1)
							throws Exception {
						// ReverseGeocode reverseGeoCode = new
						// ReverseGeocode(new
						// FileInputStream("/home/duykhanh/Desktop/ITSData/OSMData.txt"),
						// true);
						// kdTree = reverseGeoCode.kdTree();
						// TODO Auto-generated method stub
						String roadName = null;
						String[] latlon = p1.split(",");
							double lat = Double.parseDouble(latlon[4]);
							double lon = Double.parseDouble(latlon[3]);
							String p2 = lat + "," + lon;
							GeoName currentNode = new GeoName(lat, lon);
							// ReverserGeocodeBingMap obj = new
							// ReverserGeocodeBingMap();
							// String roadName = obj.main(latlon[0], latlon[1]);
							GeoName reversePoint = broadcastVal.value()
									.findNearest(currentNode);
							double distance = CoordinateDistance.distance(lat,
									lon, reversePoint.latitude,
									reversePoint.longitude);
							if (distance > 7.3) {
								roadName = "No Name Street";
							} else {
								roadName = reversePoint.toString();
							}
							// = broadcastVal.value().findNearest(new
							// GeoName(lat,
							// lon)).toString();
						return new Tuple2<String, String>(roadName, p2);
					}
				}).groupByKey().cache();

		// JavaPairRDD<String, Integer> result = listRoad
		// .mapToPair(new PairFunction<Tuple2<String, Iterable<String>>, String,
		// Integer>() {
		// public Tuple2<String, Integer> call(
		// Tuple2<String, Iterable<String>> tuple1)
		// throws Exception {
		// // TODO Auto-generated method stub
		// String result_1 = tuple1._1();
		// Iterator<String> iterator = tuple1._2().iterator();
		// Integer n = 0;
		// while (iterator.hasNext()) {
		// n++;
		// iterator.next();
		// }
		// System.out.println(n);
		// return new Tuple2<String, Integer>(result_1, n);
		// }
		// });
		//
		// List<Tuple2<String, Integer>> output = result.collect();

		JavaPairRDD<String, String> result = listRoad
				.mapToPair(new PairFunction<Tuple2<String, Iterable<String>>, String, String>() {
					public Tuple2<String, String> call(
							Tuple2<String, Iterable<String>> tuple1)
							throws Exception {
						// TODO Auto-generated method stub
						String result_1 = tuple1._1();
						// Iterator<String> iterator = tuple1._2().iterator();
						Integer n = 0;
						String test = "";
						for (String s : tuple1._2()) {
							// n++;
							test = test + "; " + s;
							// iterator.next();
						}
						System.out.println(n);
						return new Tuple2<String, String>(result_1, test);
					}
				});

		List<Tuple2<String, String>> output = result.collect();
		sparkTime.stop();

		ArrayList<String> listITSStatistic = new ArrayList<String>();
		for (Tuple2<?, ?> tuple : output) {
			// System.out.println("The road " + tuple._1() + " have " +
			// tuple._2()
			// + " car moving across");
			String dataStatistic = tuple._1() + "\t" + tuple._2();
			listITSStatistic.add(dataStatistic);
		}
		// end
		allTime.stop();

		System.out.println("Entire statistical process make up: "
				+ allTime.getSeconds() + "s");
		System.out.println("Spark process make up: " + sparkTime.getSeconds()
				+ "s");

		Write_In_File obj = new Write_In_File();
		obj.Write_File(listITSStatistic, "ITSStatistic.txt");

		// HashTable
		// HashMap<String, Integer> roadStatistic = new HashMap<String,
		// Integer>();
		// ReverserGeocodeBingMap obj = new ReverserGeocodeBingMap();
		// for(int i = 0; i < listLatLon.size(); i++){
		// String[] latlon = listLatLon.get(i).split(";");
		// String roadName = obj.main(latlon[0], latlon[1]);
		// if(roadStatistic.containsKey(roadName)){
		// Integer n = roadStatistic.get(roadName) + 1;
		// roadStatistic.put(roadName, n);
		// } else {
		// roadStatistic.put(roadName, 1);
		// }
		// }
		//
		// for(String key : roadStatistic.keySet()){
		// System.out.println("Road Name: " + key + " have " +
		// roadStatistic.get(key) + " car moving across");
		// }
		// end
		// basicTransformationQuery(simpleFeatureTypeName, featureStore);
		// renamedTransformationQuery(simpleFeatureTypeName, featureStore);
		// mutliFieldTransformationQuery(simpleFeatureTypeName, featureStore);
		// geometricTransformationQuery(simpleFeatureTypeName, featureStore);

		// the list of available transform functions is available here:
		// http://docs.geotools.org/latest/userguide/library/main/filter.html -
		// scroll to 'Function List'
	}
}
