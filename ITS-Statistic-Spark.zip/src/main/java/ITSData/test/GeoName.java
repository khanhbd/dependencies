/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ITSData.test;

import ITSData.test.kdtree.KDNodeComparator;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.toRadians;

import java.io.Serializable;
import java.util.Comparator;

/**
 *
 * @author DuyKhanh
 */
public class GeoName extends KDNodeComparator<GeoName> implements Serializable{

    public String name;
    public String data;
    public boolean majorPlace;
    public double latitude;
    public double longitude;
    public double point[] = new double[3]; // tá»a Ä‘á»™ Ä‘Æ°á»£c chuyá»ƒn sang dáº¡ng x, y, z
//    public String country;

    GeoName(String data) {
        String[] names = data.split("\t");
        name = names[0];
        this.data = data;
//        majorPlace = names[6].equals("P");
        latitude = Double.parseDouble(names[1]);
        longitude = Double.parseDouble(names[2]);
        setPoint();
//        country = names[8];
    }

    GeoName(Double latitude, Double longitude) {
        name = "Search";
        this.latitude = latitude;
        this.longitude = longitude;
        setPoint();
    }

    private void setPoint() {
        point[0] = cos(toRadians(latitude)) * cos(toRadians(longitude));
        point[1] = cos(toRadians(latitude)) * sin(toRadians(longitude));
        point[2] = sin(toRadians(latitude));
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    protected Double squaredDistance(Object other) {
        GeoName location = (GeoName) other;
        double x = this.point[0] - location.point[0];
        double y = this.point[1] - location.point[1];
        double z = this.point[2] - location.point[2];
        return (x * x) + (y * y) + (z * z);
    }

    @Override
    protected Double axisSquaredDistance(Object other, Integer axis) {
        GeoName location = (GeoName) other;
        Double distance = point[axis] - location.point[axis];
        return distance * distance;
    }

    @Override
    protected Comparator<GeoName> getComparator(Integer axis) {
        return GeoNameComparator.values()[axis];
    }

    protected static enum GeoNameComparator implements Comparator<GeoName> {

        x {
            public int compare(GeoName a, GeoName b) {
                return Double.compare(a.point[0], b.point[0]);
            }
        },
        y {
            public int compare(GeoName a, GeoName b) {
                return Double.compare(a.point[1], b.point[1]);
            }
        },
        z {
            public int compare(GeoName a, GeoName b) {
                return Double.compare(a.point[2], b.point[2]);
            }
        };
    }
}
