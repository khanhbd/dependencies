/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ITSData.test;

import ITSData.test.kdtree.KDTree;
import java.io.*;
import java.util.ArrayList;

import tachyon.thrift.WorkerService.Processor.returnSpace;

/**
 *
 * @author DuyKhanh
 */
public class ReverseGeocode {

//    public static KDTree<GeoName> kdTree;
    public static ArrayList<GeoName> arPlaceNames;

//    public static void main(String[] args) throws IOException {
//        try {
//            ReverseGeocode reverseGeoCode = new ReverseGeocode(new FileInputStream("D://test/OSMData.txt"), true);
//            StopWatch obj = new StopWatch();
//            obj.start();
//            System.out.println(reverseGeoCode.nearestPlace(10.7808055, 106.7079739));
//            obj.stop();
//            System.out.println(obj.getSeconds());
//        } catch (FileNotFoundException e) {
//            // TODO Auto-generated catch block
//            System.out.println("Kiá»ƒm tra láº¡i Ä‘Æ°á»ng dáº«n file!");
//            e.printStackTrace();
//        }
//    }

    // Get placenames from http://download.geonames.org/export/dump/
    public ReverseGeocode(InputStream placenames, Boolean majorOnly) throws IOException {
//        ArrayList<GeoName> arPlaceNames;
        arPlaceNames = new ArrayList<GeoName>();
        // Read the geonames file in the directory
        BufferedReader in = new BufferedReader(new InputStreamReader(placenames));
        String str;
        try {
            while ((str = in.readLine()) != null) {
                GeoName newPlace = new GeoName(str);
//                if (!majorOnly || newPlace.majorPlace) {
                arPlaceNames.add(new GeoName(str));
//                }
            }
        } catch (IOException ex) {
            in.close();
            throw ex;
        }
        in.close();
//        kdTree = new KDTree<GeoName>(arPlaceNames);
    }
    
    public KDTree<GeoName> kdTree(){
//    	KDTree<GeoName> kdTree;
    	return new KDTree<GeoName>(arPlaceNames);
    }

//    public GeoName nearestPlace(double latitude, double longitude) {
//
//        return kdTree.findNearest(new GeoName(latitude, longitude));
//    }
}
