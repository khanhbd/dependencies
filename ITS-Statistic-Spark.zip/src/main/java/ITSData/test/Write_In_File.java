/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ITSData.test;
import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author DuyKhanh
 */
public class Write_In_File {

	public void Write_File(ArrayList<String> list_Device, String name_File) throws IOException{
        FileWriter fw = null;
        try{
            fw = new FileWriter(CONST.path_to_output_file+"/"+name_File);
        }catch(IOException e){
            System.out.printf("Khong mo duoc file");
        }
        String Str;
        for(int i = 0; i< list_Device.size(); i++){
            Str = list_Device.get(i);
            Str = Str + "\r\n";
            fw.write(Str);
        }
        fw.close();
    }
}
