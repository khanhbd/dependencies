package ITSData.test;

import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.toRadians;
import static java.lang.Math.atan2;
import static java.lang.Math.sqrt;

public class CoordinateDistance {
	public static double distance(double lat1, double lon1, double lat2,
			double lon2) {
		double R = 6371000;
		// double lat1 = 10.7276677;
		// double lat2 = 10.7276053;
		double deltaLat = lat1 - lat2;
		// double lon1 = 106.6017927;
		// double lon2 = 106.6017841;
		double deltaLon = lon1 - lon2;
		double a = sin(toRadians(deltaLat / 2)) * sin(toRadians(deltaLat / 2))
				+ cos(toRadians(lat1)) * cos(toRadians(lat2))
				* sin(toRadians(deltaLon)) * sin(toRadians(deltaLon));
		double c = 2 * atan2(sqrt(a), sqrt(1 - a));
		double d = R * c;
		return d;
		// System.out.println(d);
	}
}
