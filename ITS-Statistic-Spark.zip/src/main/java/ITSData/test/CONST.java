package ITSData.test;

public class CONST {

	public static String path_to_output_file = "/home/duykhanh/Desktop/ITSData";
	public static String path_to_input_file = "/home/duykhanh/Desktop";
}
