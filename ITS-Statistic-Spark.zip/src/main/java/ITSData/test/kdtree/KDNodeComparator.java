/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ITSData.test.kdtree;

import java.util.Comparator;
/**
 *
 * @author DuyKhanh
 */
public abstract class KDNodeComparator<T> {
    protected abstract Comparator<T> getComparator(Integer axis);
    
    protected abstract <T> Double squaredDistance(T other);
    
    protected abstract <T> Double axisSquaredDistance(T other, Integer axis);
}
