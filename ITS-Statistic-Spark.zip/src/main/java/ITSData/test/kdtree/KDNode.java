/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ITSData.test.kdtree;

import java.io.Serializable;

/**
 *
 * @author DuyKhanh
 */
public class KDNode <T extends KDNodeComparator<T>> implements Serializable{
    KDNode<T> left;
    KDNode<T> right;
    T location;

    public KDNode( KDNode<T> left, KDNode<T> right, T location ) {
        this.left = left;
        this.right = right;
        this.location = location;
    }

}
